export const environment = {
  appName: 'TopViewAI',
  gateway: 'https://topview-ai.com/api/',
};
